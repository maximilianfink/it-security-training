module.exports = require('lodash');
