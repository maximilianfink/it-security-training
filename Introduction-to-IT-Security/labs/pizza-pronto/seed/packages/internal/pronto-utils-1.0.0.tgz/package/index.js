// Internal helpers of Pizza Pronto
function formatPrice(cents) {
  return (cents / 100).toFixed(2).replace('.', ',') + ' €';
}

function deliveryEta(address) {
  const minutes = 25 + (String(address).length % 4) * 5;
  return `${minutes} minutes`;
}

module.exports = { formatPrice, deliveryEta };
