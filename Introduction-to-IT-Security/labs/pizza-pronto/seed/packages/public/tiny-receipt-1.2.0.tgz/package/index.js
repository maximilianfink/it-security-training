'use strict';

const LINE = '-'.repeat(32);

function pad(left, right, width = 32) {
  const space = Math.max(1, width - left.length - right.length);
  return left + ' '.repeat(space) + right;
}

function money(cents) {
  return (cents / 100).toFixed(2) + ' EUR';
}

function renderReceipt(order) {
  const lines = [
    LINE,
    pad('Order #' + order.id, new Date(order.createdAt || Date.now()).toLocaleTimeString('de-DE')),
    LINE,
    ...order.items.map((item) => '1x ' + item),
    LINE,
    pad('TOTAL', money(order.total || 0)),
    LINE,
  ];
  return lines.join('\n');
}

module.exports = { renderReceipt };
